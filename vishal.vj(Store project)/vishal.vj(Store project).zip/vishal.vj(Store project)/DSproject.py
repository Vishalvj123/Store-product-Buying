
vj={"BISCUIT":{"Monaco":25,"Oreo":10,"Bourbon":35,"Sunfest":15,"Richbar":40},
        "COOKIES":{"Choco":20,"Fortune":20,"Oreo":25,"FigRoll":40,"Sugar":50},
       "CHIPS":{"Lays":5,"Kurkure":5,"Bingo":5,"Cheetos":10,"Tofo":2},
       "JUICE":{"Miranda":20,"Slise":25,"coco cola":20,"Fanta":10,"Maza":25},
       "CHOKI": {"Dairymilk": 50, "5 star": 10, "Milkybar": 100, "Munch": 50}
       }
